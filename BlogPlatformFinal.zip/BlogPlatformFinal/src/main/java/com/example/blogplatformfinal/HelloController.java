package com.example.blogplatformfinal;

import java.lang.NullPointerException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import java.io.IOException;
import javafx.scene.Parent;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Label;

import java.sql.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import java.io.IOException;

import java.lang.Class;
import java.sql.Connection;
import java.sql.DriverManager;


public class HelloController {

    private Stage stage;
    private Scene scene;
    private Parent root;

    @FXML
    private Label loginlabel;

    @FXML
    private TextField usernameField;
    @FXML
    private TextField passwordField;

    public HelloController() throws IOException {
    }

    @FXML
    public void onLoginButtonClick(ActionEvent event) throws IOException {
        FXMLLoader loginfxmlLoader = new FXMLLoader(HelloApplication.class.getResource("loginpage.fxml"));


        Scene firstscene = new Scene(loginfxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Login");
        stage.setScene(firstscene);
        stage.show();
    }
    @FXML
    public void onSignupButtonClick(ActionEvent event) throws IOException {
        FXMLLoader loginfxmlLoader = new FXMLLoader(HelloApplication.class.getResource("signuppage.fxml"));


        Scene firstscene = new Scene(loginfxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Sign up");
        stage.setScene(firstscene);
        stage.show();
    }

    public class DatabaseConnection {
        public  Connection databaselink;
        public  Connection getConnection() throws ClassNotFoundException {
            String databaseName="loginpageschema";
            String databaseUser ="root";
            String databasePassword ="*prithiCSE4*";
            String url= "jdbc:mysql://localhost/loginpageschema" ;
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                databaselink= DriverManager.getConnection(url,databaseUser,databasePassword);
                System.out.println("DB connection success");

            }
            catch (Exception e){
                e.printStackTrace();
            }
            return databaselink;
        }
    }

    private static DatabaseConnection connect;

    public void validateLogin() throws ClassNotFoundException,SQLException {
        connect =  new DatabaseConnection();
        Connection connectDb =connect.getConnection();

        String verifyLogin = "select count(1) from logintable where name='"+usernameField.getText()+"' and password='"+passwordField.getText()+"'";
        try {
            Statement statement = connectDb.createStatement();
            ResultSet  queryresult= statement.executeQuery(verifyLogin);
            while(queryresult.next()){

                if(queryresult.getInt( 1)==1){
                    loginlabel.setText("Login success");
                }
                else{
                    loginlabel.setText("Enter correct username and password");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    @FXML
    public void onLoginButton2Click(ActionEvent event) throws IOException, ClassNotFoundException, SQLException {

        if(usernameField.getText().isBlank() == false && passwordField.getText().isBlank() == false){

            validateLogin();
        }
        FXMLLoader loginfxmlLoader = new FXMLLoader(HelloApplication.class.getResource("dashboard.fxml"));


        Scene firstscene = new Scene(loginfxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Dashboard");
        stage.setScene(firstscene);
        stage.show();
    }

    @FXML
    public void onSignupButton2Click(ActionEvent event) throws IOException {
        FXMLLoader loginfxmlLoader = new FXMLLoader(HelloApplication.class.getResource("dashboard.fxml"));


        Scene firstscene = new Scene(loginfxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Dashboard");
        stage.setScene(firstscene);
        stage.show();
    }
    @FXML
    public void onHomeButtonClick(ActionEvent event) throws IOException {
        FXMLLoader loginfxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));


        Scene firstscene = new Scene(loginfxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Home");
        stage.setScene(firstscene);
        stage.show();
    }
    public void onProfileButtonClick(ActionEvent event) throws IOException {
        FXMLLoader loginfxmlLoader = new FXMLLoader(HelloApplication.class.getResource("profile.fxml"));


        Scene firstscene = new Scene(loginfxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Profile");
        stage.setScene(firstscene);
        stage.show();
    }
    public void onBlogButtonClick(ActionEvent event) throws IOException {
        FXMLLoader loginfxmlLoader = new FXMLLoader(HelloApplication.class.getResource("blog.fxml"));


        Scene firstscene = new Scene(loginfxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Blog");
        stage.setScene(firstscene);
        stage.show();
    }
    public void onCommentButtonClick(ActionEvent event) throws IOException {
        FXMLLoader loginfxmlLoader = new FXMLLoader(HelloApplication.class.getResource("comments.fxml"));


        Scene firstscene = new Scene(loginfxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Comment");
        stage.setScene(firstscene);
        stage.show();
    }
    public void onSettingButtonClick(ActionEvent event) throws IOException {
        FXMLLoader loginfxmlLoader = new FXMLLoader(HelloApplication.class.getResource("settings.fxml"));


        Scene firstscene = new Scene(loginfxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Setting");
        stage.setScene(firstscene);
        stage.show();
    }
}